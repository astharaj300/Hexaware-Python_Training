
class Courier:
    def __init__(self, courier_id, sender_name, sender_address, receiver_name, receiver_address, weight, status, tracking_number, delivery_date):
        self.courier_id = courier_id
        self.sender_name = sender_name
        self.sender_address = sender_address
        self.receiver_name = receiver_name
        self.receiver_address = receiver_address
        self.weight = weight
        self.status = status
        self.tracking_number = tracking_number
        self.delivery_date = delivery_date
