# entity/User.py
class User:
    def __init__(self, user_id, name, email, password, contact_number, address):
        self.user_id = user_id
        self.name = name
        self.email = email
        self.password = password
        self.contact_number = contact_number
        self.address = address
