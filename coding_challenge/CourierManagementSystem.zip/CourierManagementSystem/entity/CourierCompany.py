
class CourierCompany:
    def __init__(self, company_id, company_name, couriers, employees, locations):
        self.company_id = company_id
        self.company_name = company_name
        self.couriers = couriers
        self.employees = employees
        self.locations = locations
