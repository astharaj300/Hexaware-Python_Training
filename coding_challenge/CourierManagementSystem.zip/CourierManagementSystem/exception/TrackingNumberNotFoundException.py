
class TrackingNumberNotFoundException(Exception):
    pass
