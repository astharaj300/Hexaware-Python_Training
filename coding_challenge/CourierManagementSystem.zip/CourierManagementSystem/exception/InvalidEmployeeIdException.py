
class InvalidEmployeeIdException(Exception):
    pass
