from dao.IHospitalServiceImpl import HospitalServiceImpl
from entity.Appointment import Appointment
from exception.custom_exceptions import PatientNumberNotFoundException


class MainModule:
    @staticmethod
    def main():

        db_config = {
            'host': 'localhost',
            'database': 'hospitalmanagementsystem',
            'user': 'root',
            'password': 'ABcd300#$',
            'port': '3306'
        }

        service = HospitalServiceImpl(db_config)

        while True:
            print("\nHospital Management System Menu:")
            print("1. Get appointment by ID")
            print("2. Get appointments for patient")
            print("3. Get appointments for doctor")
            print("4. Schedule appointment")
            print("5. Update appointment")
            print("6. Cancel appointment")
            print("7. Exit")

            choice = input("Enter your choice: ")

            if choice == "1":
                appointment_id = int(input("Enter appointment ID: "))
                try:
                    appointment = service.getAppointmentById(appointment_id)
                    print(appointment)
                except PatientNumberNotFoundException as e:
                    print(e)

            elif choice == "2":
                patient_id = int(input("Enter patient ID: "))
                try:
                    appointments = service.getAppointmentsForPatient(patient_id)
                    for appointment in appointments:
                        print(appointment)
                except PatientNumberNotFoundException as e:

                    print(e)

            elif choice == "3":
                doctor_id = int(input("Enter doctor ID: "))
                appointments = service.getAppointmentsForDoctor(doctor_id)
                for appointment in appointments:
                    print(appointment)

            elif choice == "4":
                patient_id = int(input("Enter patient ID: "))
                doctor_id = int(input("Enter doctor ID: "))
                appointment_date = input("Enter appointment date (YYYY-MM-DD HH:MM:SS): ")
                description = input("Enter appointment description: ")
                new_appointment = Appointment(patientId=patient_id, doctorId=doctor_id, appointmentDate=appointment_date, description=description)
                success = service.scheduleAppointment(new_appointment)
                if success:
                    print("Appointment scheduled successfully")
                else:
                    print("Failed to schedule appointment")

            elif choice == "5":
                appointment_id = int(input("Enter appointment ID: "))
                patient_id = int(input("Enter new patient ID: "))
                doctor_id = int(input("Enter new doctor ID: "))
                appointment_date = input("Enter new appointment date (YYYY-MM-DD HH:MM:SS): ")
                description = input("Enter new appointment description: ")
                updated_appointment = Appointment(appointmentId=appointment_id, patientId=patient_id, doctorId=doctor_id, appointmentDate=appointment_date, description=description)
                success = service.updateAppointment(updated_appointment)
                if success:
                    print("Appointment updated successfully")
                else:
                    print("Failed to update appointment")

            elif choice == "6":
                appointment_id = int(input("Enter appointment ID to cancel: "))
                success = service.cancelAppointment(appointment_id)
                if success:
                    print("Appointment canceled successfully")
                else:
                    print("Failed to cancel appointment")

            elif choice == "7":
                print("Exiting...")
                break

            else:
                print("Invalid choice. Please try again.")

if __name__ == "__main__":
    MainModule.main()
