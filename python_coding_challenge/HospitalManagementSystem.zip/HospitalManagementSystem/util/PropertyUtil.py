from configparser import ConfigParser


class PropertyUtil:
    @staticmethod
    def getPropertyString():
        config = ConfigParser()
        config.read('database.ini')

        hostname = config['DATABASE']['hostname']
        dbname = config['DATABASE']['dbname']
        username = config['DATABASE']['username']
        password = config['DATABASE']['password']
        port = config['DATABASE']['port']

        connection_string = {
            'host': hostname,
            'database': dbname,
            'user': username,
            'password': password,
            'port': port
        }
        return connection_string
