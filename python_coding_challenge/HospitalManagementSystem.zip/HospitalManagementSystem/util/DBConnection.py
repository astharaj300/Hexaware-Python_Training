import mysql.connector

from util.PropertyUtil import PropertyUtil


class DBConnection:
    connection = None

    @staticmethod
    def getConnection():
        if DBConnection.connection is None:
            connection_string = PropertyUtil.getPropertyString()
            DBConnection.connection = mysql.connector.connect(**connection_string)
        return DBConnection.connection
