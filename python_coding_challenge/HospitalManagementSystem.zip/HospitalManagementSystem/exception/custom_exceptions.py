class PatientNumberNotFoundException(Exception):
    pass
