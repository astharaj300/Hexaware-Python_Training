import mysql.connector
from typing import List
from dao.IHospitalService import IHospitalService
from entity.Appointment import Appointment
from exception.custom_exceptions import PatientNumberNotFoundException


class HospitalServiceImpl(IHospitalService):
    def __init__(self, db_config):
        self.connection = mysql.connector.connect(**db_config)
        self.cursor = self.connection.cursor()

    def getAppointmentById(self, appointmentId: int) -> Appointment:
        query = "SELECT * FROM appointment WHERE appointmentId = %s"
        self.cursor.execute(query, (appointmentId,))
        result = self.cursor.fetchone()
        if result:
            return Appointment(*result)
        else:
            raise PatientNumberNotFoundException(f"Appointment with ID {appointmentId} not found")

    def getAppointmentsForPatient(self, patientId: int) -> List[Appointment]:
        query = "SELECT * FROM appointment WHERE patientId = %s"
        self.cursor.execute(query, (patientId,))
        results = self.cursor.fetchall()
        if results:
            return [Appointment(*result) for result in results]
        else:
            raise PatientNumberNotFoundException(f"No appointments found for patient with ID {patientId}")

    def getAppointmentsForDoctor(self, doctorId: int) -> List[Appointment]:
        query = "SELECT * FROM appointment WHERE doctorId = %s"
        self.cursor.execute(query, (doctorId,))
        results = self.cursor.fetchall()
        return [Appointment(*result) for result in results]

    def scheduleAppointment(self, appointment: Appointment) -> bool:
        query = "INSERT INTO appointment (patientId, doctorId, appointmentDate, description) VALUES (%s, %s, %s, %s)"
        data = (appointment.patientId, appointment.doctorId, appointment.appointmentDate, appointment.description)
        self.cursor.execute(query, data)
        self.connection.commit()
        return True

    def updateAppointment(self, appointment: Appointment) -> bool:
        query = "UPDATE appointment SET patientId = %s, doctorId = %s, appointmentDate = %s, description = %s WHERE appointmentId = %s"
        data = (appointment.patientId, appointment.doctorId, appointment.appointmentDate, appointment.description, appointment.appointmentId)
        self.cursor.execute(query, data)
        self.connection.commit()
        return True

    def cancelAppointment(self, appointmentId: int) -> bool:
        query = "DELETE FROM appointment WHERE appointmentId = %s"
        self.cursor.execute(query, (appointmentId,))
        self.connection.commit()
        return True
