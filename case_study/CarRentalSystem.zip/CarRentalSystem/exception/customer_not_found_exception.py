class CustomerNotFoundException(Exception):
   pass