
class CarNotFoundException(Exception):
   pass


