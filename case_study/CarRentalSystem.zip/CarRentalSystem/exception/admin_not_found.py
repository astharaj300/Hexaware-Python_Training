class AdminNotFoundException(Exception):
    pass