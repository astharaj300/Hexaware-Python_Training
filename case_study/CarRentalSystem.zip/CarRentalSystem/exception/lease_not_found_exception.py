class LeaseNotFoundException(Exception):
    pass


class ActiveLeasesExistException(Exception):
    pass
