class Vehicle:
    def __init__(self, vehicleID, make, model, year, dailyRate, status, passengerCapacity, engineCapacity):
        self._vehicleID = vehicleID
        self._make = make
        self._model = model
        self._year = year
        self._dailyRate = dailyRate
        self._status = status
        self._passengerCapacity = passengerCapacity
        self._engineCapacity = engineCapacity

    @property
    def vehicleID(self):
        return self._vehicleID

    @property
    def make(self):
        return self._make

    @property
    def model(self):
        return self._model

    @property
    def year(self):
        return self._year

    @property
    def dailyRate(self):
        return self._dailyRate

    @property
    def status(self):
        return self._status

    @property
    def passengerCapacity(self):
        return self._passengerCapacity

    @property
    def engineCapacity(self):
        return self._engineCapacity
