class Vehicle:
    def __init__(self, vehicleID, make, model, year, dailyRate, status, passengerCapacity, engineCapacity):
        self.__vehicleID = vehicleID
        self.__make = make
        self.__model = model
        self.__year = year
        self.__dailyRate = dailyRate
        self.__status = status
        self.__passengerCapacity = passengerCapacity
        self.__engineCapacity = engineCapacity

    @property
    def vehicleID(self):
        return self.__vehicleID

    @property
    def make(self):
        return self.__make

    @make.setter
    def make(self, set_make):
        self.__make = set_make

    @property
    def model(self):
        return self.__model

    @model.setter
    def model(self, set_model):
        self.__model = set_model

    @property
    def year(self):
        return self.__year

    @year.setter
    def year(self, set_year):
        self.__year = set_year

    @property
    def dailyRate(self):
        return self.__dailyRate

    @dailyRate.setter
    def dailyRate(self, set_dailyRate):
        self.__dailyRate = set_dailyRate

    @property
    def status(self):
        return self.__status

    @status.setter
    def status(self, set_status):
        self.__status = set_status

    @property
    def passengerCapacity(self):
        return self.__passengerCapacity

    @passengerCapacity.setter
    def passengerCapacity(self, passenger_capacity):
        self.__passengerCapacity = passenger_capacity

    @property
    def engineCapacity(self):
        return self.__engineCapacity

    @engineCapacity.setter
    def engineCapacity(self, engine_capacity):
        self.__engineCapacity = engine_capacity
