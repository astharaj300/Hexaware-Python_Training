class Payment:
    def __init__(self, paymentID, leaseID, paymentDate, amount):
        self._paymentID = paymentID
        self._leaseID = leaseID
        self._paymentDate = paymentDate
        self._amount = amount

    @property
    def paymentID(self):
        return self._paymentID

    @property
    def leaseID(self):
        return self._leaseID
    @property
    def paymentDate(self):
        return self._paymentDate

    @property
    def amount(self):
        return self._amount
