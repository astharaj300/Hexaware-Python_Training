class Lease:
    def __init__(self, leaseID, vehicleID, customerID, startDate, endDate, type):
        self.__leaseID = leaseID
        self.__vehicleID = vehicleID
        self.__customerID = customerID
        self.__startDate = startDate
        self.__endDate = endDate
        self.__type = type


    @property
    def leaseID(self):
        return self.__leaseID

    @property
    def vehicleID(self):
        return self.__vehicleID

    @property
    def customerID(self):
        return self.__customerID

    @property
    def startDate(self):
        return self.__startDate

    @startDate.setter
    def startDate(self, set_startDate):
        self.__startDate = set_startDate

    @property
    def endDate(self):
        return self.__endDate

    @endDate.setter
    def endDate(self, set_endDate):
        self.__endDate = set_endDate

    @property
    def type(self):
        return self.__type

    @type.setter
    def type(self, set_type):
        self.__type = set_type

