class Customer:
    def __init__(self, customerID, firstName, lastName, email, phoneNumber):
        self.__customerID = customerID
        self.__firstName = firstName
        self.__lastName = lastName
        self.__email = email
        self.__phoneNumber = phoneNumber

    @property
    def customerID(self):
        return self.__customerID

    @property
    def firstName(self):
        return self.__firstName

    @firstName.setter
    def firstName(self, first_name):
        self.__firstName = first_name

    @property
    def lastName(self):
        return self.__lastName

    @lastName.setter
    def lastName(self, last_name):
        self.__lastName = last_name

    @property
    def email(self):
        return self.__email

    @email.setter
    def email(self, set_email):
        self.__email = set_email

    @property
    def phoneNumber(self):
        return self.__phoneNumber

    @phoneNumber.setter
    def phoneNumber(self, phone_number):
        self.__phoneNumber = phone_number
