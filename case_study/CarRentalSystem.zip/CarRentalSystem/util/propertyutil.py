class propertyUtil:

    @staticmethod
    def getPropertyString():
        connection_string = {
            'host': "localhost",
            'database': "carrentalsystemm",
            'user': "root",
            'password': "ABcd300#$"
        }

        return connection_string
