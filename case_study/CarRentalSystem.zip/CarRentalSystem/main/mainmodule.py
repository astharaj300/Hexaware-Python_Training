from dao.icarleaserepositoryimpl import ICarLeaseRepositoryImpl
from entity.vehicle import Vehicle
from entity.customer import Customer
from exception.car_not_found_exception import CarNotFoundException
from exception.customer_not_found_exception import CustomerNotFoundException
from exception.lease_not_found_exception import LeaseNotFoundException
from util.dbconnection import DBConnection


class MainModule:

    def __init__(self):
        self.car_repository = ICarLeaseRepositoryImpl(DBConnection.getConnection())

    def display_menu(self):
        print("\nCar Rental System Menu:")
        print("1. Add a Car")
        print("2. Remove a Car")
        print("3. List Available Cars")
        print("4. List Rented Cars")
        print("5. Find Car by ID")
        print("6. Add a Customer")
        print("7. Remove a Customer")
        print("8. List Customers")
        print("9. Find Customer by ID")
        print("10. Create Lease")
        print("11. Return Car")
        print("12. List Active Leases")
        print("13. List Lease History")
        print("14. Record Payment")
        print("15. Exit")

    def run(self):
        while True:
            self.display_menu()
            choice = input("Enter your choice (1-15): ")

            if choice == "15":
                print("Exiting Car Rental System. Goodbye!")
                break
            elif choice == "1":
                self.add_car()
            elif choice == "2":
                self.remove_car()
            elif choice == "3":
                self.list_available_cars()
            elif choice == "4":
                self.list_rented_cars()
            elif choice == "5":
                self.find_car_by_id()
            elif choice == "6":
                self.add_customer()
            elif choice == "7":
                self.remove_customer()
            elif choice == "8":
                self.list_customers()
            elif choice == "9":
                self.find_customer_by_id()
            elif choice == "10":
                self.create_lease()
            elif choice == "11":
                self.return_car()
            elif choice == "12":
                self.list_active_leases()
            elif choice == "13":
                self.list_lease_history()
            elif choice == "14":
                self.record_payment()
            else:
                print("Invalid choice. Please enter a valid option.")

    def add_car(self):
        print("Adding a new Car:")
        make = input("Enter Make: ")
        model = input("Enter Model: ")
        year = input("Enter Year: ")
        daily_rate = input("Enter Daily Rate: ")
        status = input("Enter Status (available/notAvailable): ")
        passenger_capacity = input("Enter Passenger Capacity: ")
        engine_capacity = input("Enter Engine Capacity: ")

        new_car = Vehicle(None, make, model, year, daily_rate, status, passenger_capacity, engine_capacity)
        self.car_repository.addCar(new_car)
        print("Great! Car added successfully.")

    def remove_car(self):
        print("Remove a Car:")
        car_id = int(input("Enter Car ID to remove: "))

        try:
            self.car_repository.removeCar(car_id)
            print("Car removed successfully.")
        except CarNotFoundException as e:
            print(f"Error: {e}")

    def list_available_cars(self):
        print("List Available Cars:")
        available_cars = self.car_repository.listAvailableCars()

        if available_cars:
            print("Available Cars:")
            for car in available_cars:
                print(f"{car.vehicleID}. {car.make} {car.model} - Status: {car.status}")
        else:
            print("No available cars.")

    def list_rented_cars(self):
        print("List Rented Cars:")
        rented_cars = self.car_repository.listRentedCars()

        if rented_cars:
            print("Rented Cars:")
            for car in rented_cars:
                print(f"{car.vehicleID}. {car.make} {car.model} - Status: {car.status}")
        else:
            print("No rented cars.")

    def find_car_by_id(self):
        print("Find Car by ID:")
        car_id = int(input("Enter Car ID to find: "))

        try:
            found_car = self.car_repository.findCarById(car_id)
            print(f"Car Found: {found_car.make} {found_car.model} - Status: {found_car.status}")
        except CarNotFoundException as e:
            print(f"Error: {e}")

    def add_customer(self):
        print("Add a Customer:")
        first_name = input("Enter First Name: ")
        last_name = input("Enter Last Name: ")
        email = input("Enter Email: ")
        phone_number = input("Enter Phone Number: ")

        new_customer = Customer(None, first_name, last_name, email, phone_number)
        self.car_repository.addCustomer(new_customer)
        print("Customer added successfully.")

    def remove_customer(self):
        print("Remove a Customer:")
        customer_id = int(input("Enter Customer ID to remove: "))
        try:
            self.car_repository.removeCustomer(customer_id)
            print("Customer removed successfully.")
        except CustomerNotFoundException as e:
            print(f"Error: {e}")

    def list_customers(self):
        print("List Customers:")
        customers = self.car_repository.listCustomers()
        if customers:
            print("Customers:")
            for customer in customers:
                print(f"{customer.customerID}. {customer.firstName} {customer.lastName} - Email: {customer.email}")
        else:
            print("No customers.")

    def find_customer_by_id(self):
        print("Find Customer by ID:")
        customer_id = int(input("Enter Customer ID to find: "))

        try:
            found_customer = self.car_repository.findCustomerById(customer_id)
            print(f"Customer Found: {found_customer.firstName} {found_customer.lastName} - Email: {found_customer.email}")
        except CustomerNotFoundException as e:
            print(f"Error: {e}")

    def create_lease(self):
        print("Creating Lease:")
        customer_id = int(input("Enter Customer ID: "))
        car_id = int(input("Enter Vehicle ID: "))
        start_date = input("Enter Start Date (YYYY-MM-DD): ")
        end_date = input("Enter End Date (YYYY-MM-DD): ")
        lease_type = input("Input type as Daily or Monthly: ")

        try:
            created_lease = self.car_repository.createLease(customer_id, car_id, start_date, end_date, lease_type)
            print(f"Lease created successfully. Lease ID: {created_lease.leaseID}")
        except (CarNotFoundException, CustomerNotFoundException) as e:
            raise e
    def return_car(self):
        print("Return Car:")
        lease_id = int(input("Enter Lease ID to return the car: "))
        try:
            returned_lease = self.car_repository.returnCar(lease_id)
            print(f"Car returned successfully. Lease ID: {returned_lease.leaseID}")
        except LeaseNotFoundException as e:
            print(f"Error: {e}")

    def list_active_leases(self):
        print("List Active Leases:")
        active_leases = self.car_repository.listActiveLeases()

        if active_leases:
            print("Active Leases:")
            for lease in active_leases:
                print(f"Lease ID: {lease.leaseID} - Start Date: {lease.startDate} - End Date: {lease.endDate}")
        else:
            print("No active leases.")

    def list_lease_history(self):
        print("List Lease History:")
        lease_history = self.car_repository.listLeaseHistory()

        if lease_history:
            print("Lease History:")
            for lease in lease_history:
                print(f"Lease ID: {lease.leaseID} - Start Date: {lease.startDate} - End Date: {lease.endDate}")
        else:
            print("No lease history.")

    def record_payment(self):
        print("Record Payment:")
        lease_id = int(input("Enter Lease ID for payment: "))
        amount = float(input("Enter Payment Amount: "))

        try:
            lease = self.car_repository.findLeaseById(lease_id)
            self.car_repository.recordPayment(lease, amount)
            print("Payment recorded successfully.")
        except LeaseNotFoundException as e:
            print(f"Error: {e}")


if __name__ == "__main__":
    main_module = MainModule()
    main_module.run()
