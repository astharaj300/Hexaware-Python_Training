from dao.icarleaserepositoryimpl import ICarLeaseRepositoryImpl
from entity.vehicle import Vehicle
from entity.customer import Customer
from exception.car_not_found_exception import CarNotFoundException
from exception.admin_not_found import AdminNotFoundException
from exception.customer_not_found_exception import CustomerNotFoundException
from exception.lease_not_found_exception import LeaseNotFoundException, ActiveLeasesExistException
from util.dbconnection import DBConnection


class MainModule:

    def __init__(self):
        self.car_repository = ICarLeaseRepositoryImpl(DBConnection.getConnection())


    @staticmethod
    def display_user_menu():
        print("\n User Menu")
        print("1. List Rented Cars")
        print("2. List Available Cars")
        print("3. Return Car")
        print("4. Record Payment")
        print("5. Retrieve Payment History for Customer")
        print("0. Exit")


    @staticmethod
    def display_admin_menu():
        print("\n Admin Menu")
        print("**************************")
        print("1. Add Customer")
        print("2. Remove Customer")
        print("3. Add a car")
        print("4. Remove a car")
        print("5. Find Customer By ID")
        print("6. Find Car By ID")
        print("7. Find lease by ID")
        print("8. List all Customers")
        print("9. Create Lease")
        print("10. List Active Leases")
        print("11. List Lease History")
        print("12. Calculate total Revenue")
        print("13. Update Customer")
        print("0. exit")

    @staticmethod
    def display_menu():
        print("\nYou are welcome in Car Rental System")
        print("1. Admin Menu")
        print("2. User Menu")
        print("0. Exiting")

    def admin_login(self):
        while True:
            password = 'admin@123'
            p1 = input("Enter the password to get admin access: ")

            if p1 == password:
                print("Correct Password: Welcome!")
                return True
            else:
                raise AdminNotFoundException("Admin Not Found")

    def user_login(self):
        while True:
            username = input("Enter username: ")
            password = input("Enter password: ")

            # Check if username and password are non-empty
            if username and password:
                print("User login successful!")
                return True
            else:
                print("Invalid username or password. Please try again.")

    def run(self):
        while True:
            self.display_menu()
            choice = input("Enter choice from (0-2)")
            if choice == "0":
                print("Exiting , GoodBye!")
                break
            if choice == "1":
                try:
                    if not self.admin_login():
                        continue
                except AdminNotFoundException as e:
                    print(f"Error: {e}")
                    continue

                while(True):

                    self.display_admin_menu()
                    choice = input("Enter choice from (0-13)")
                    if choice == "0":
                        print("Exiting Car Rental System. Goodbye!")
                        break
                    elif choice == "1":
                        self.add_customer()
                    elif choice == "2":
                        self.remove_customer()
                    elif choice == "3":
                        self.add_car()
                    elif choice == "4":
                        self.remove_car()
                    elif choice == "5":
                        self.find_customer_by_id()
                    elif choice == "6":
                        self.find_car_by_id()
                    elif choice == "7":
                        self.find_lease_by_id()
                    elif choice == "8":
                        self.list_customers()
                    elif choice == "9":
                        self.create_lease()
                    elif choice == "10":
                        self.list_active_leases()
                    elif choice == "11":
                        self.list_lease_history()
                    elif choice == "12":
                        self.calculate_total_revenue()
                    elif choice == "13":
                        self.update_customer_info()
                    else:
                        print("Invalid choice. Please enter a valid option.")

            elif choice == "2":

                if not self.user_login():
                    continue

                while (True):
                    self.display_user_menu()
                    choice = input("Enter choice from (0-4)")

                    if choice == "0":
                        print("Exiting Car Rental System. Goodbye!")
                        break
                    elif choice == "1":
                        self.list_rented_cars()
                    elif choice == "2":
                        self.list_available_cars()
                    elif choice == "3":
                        self.return_car()
                    elif choice == "4":
                        self.record_payment()
                    elif choice == "5":
                        self.retrieve_payment_history()
                    else:
                        print("Invalid choice. Please enter a valid option.")

    def add_car(self):
        print("Adding a new Car:")
        make = input("Enter Make: ")
        model = input("Enter Model: ")
        year = input("Enter Year: ")
        daily_rate = input("Enter Daily Rate: ")
        status = input("Enter Status (Available/NotAvailable): ")
        passenger_capacity = input("Enter Passenger Capacity: ")
        engine_capacity = input("Enter Engine Capacity: ")

        new_car = Vehicle(None, make, model, year, daily_rate, status, passenger_capacity, engine_capacity)
        self.car_repository.addCar(new_car)
        print(f"Great! Car added successfully. {new_car.vehicleID}")

    def remove_car(self):
        print("Remove a Car:")
        car_id = int(input("Enter Car ID to remove: "))

        try:
            self.car_repository.removeCar(car_id)
            print("Car removed successfully.")
        except CarNotFoundException as e:
            print(f"Error: {e}")
        except ActiveLeasesExistException as e:
            print(f"Error: {e}")

    def list_available_cars(self):
        print("List Available Cars:")
        available_cars = self.car_repository.listAvailableCars()

        if available_cars:
            print("Available Cars:")
            for car in available_cars:
                print(f"{car.vehicleID}. {car.make} {car.model} - Status: {car.status}")
        else:
            print("No available cars.")

    def list_rented_cars(self):
        print("List Rented Cars:")
        rented_cars = self.car_repository.listRentedCars()

        if rented_cars:
            print("Rented Cars:")
            for car in rented_cars:
                print(f"{car.vehicleID}. {car.make} {car.model} - Status: {car.status}")
        else:
            print("No rented cars.")

    def find_car_by_id(self):
        print("Find Car by ID:")
        car_id = int(input("Enter Car ID to find: "))

        try:
            found_car = self.car_repository.findCarById(car_id)
            print(f"Car Found: {found_car.make} {found_car.model} - Status: {found_car.status}")
        except CarNotFoundException as e:
            print(f"Error: {e}")

    def add_customer(self):
        print("Add a Customer:")
        first_name = input("Enter First Name: ")
        last_name = input("Enter Last Name: ")
        email = input("Enter Email: ")
        phone_number = input("Enter Phone Number: ")

        new_customer = Customer(None, first_name, last_name, email, phone_number)
        self.car_repository.addCustomer(new_customer)
        print("Customer added successfully.")

    def remove_customer(self):
        print("Remove a Customer:")
        customer_id = int(input("Enter Customer ID to remove: "))

        try:
            self.car_repository.removeCustomer(customer_id)
            print("Customer removed successfully.")
        except CustomerNotFoundException as e:
            print(f"Error: {e}")
        except ActiveLeasesExistException as e:
            print(f"Error: {e}")

    def update_customer_info(self):
        customer_id = int(input("Enter Customer ID: "))
        if self.car_repository.findCustomerById(customer_id):
            new_email = input("Enter new Email (leave blank to keep unchanged): ").strip() or None
            new_phone = input("Enter new Phone (leave blank to keep unchanged): ").strip() or None

            self.car_repository.update_customer_info(customer_id, new_email, new_phone)
            print("Customer information updated successfully.")
        else:
            print("Not found.")

    def list_customers(self):
        print("List Customers:")
        customers = self.car_repository.listCustomers()
        if customers:
            print("Customers:")
            for customer in customers:
                print(f"{customer.customerID}. {customer.firstName} {customer.lastName} - Email: {customer.email}"
                      f",  PhoneNumber: {customer.phoneNumber}")
        else:
            print("No customers.")

    def find_customer_by_id(self):
        print("Find Customer by ID:")
        customer_id = int(input("Enter Customer ID to find: "))

        try:
            found_customer = self.car_repository.findCustomerById(customer_id)
            print(f"Customer Found: {found_customer.firstName} {found_customer.lastName} - Email: {found_customer.email}")
        except CustomerNotFoundException as e:
            print(f"Error: {e}")

    def create_lease(self):
        print("Creating Lease:")
        customer_id = int(input("Enter Customer ID: "))
        car_id = int(input("Enter Vehicle ID: "))
        start_date = input("Enter Start Date (YYYY-MM-DD): ")
        end_date = input("Enter End Date (YYYY-MM-DD): ")
        lease_type = input("Input type as DailyLease or MonthlyLease: ")

        try:
            created_lease = self.car_repository.createLease(customer_id, car_id, start_date, end_date, lease_type)
            print(f"Lease created successfully. Lease ID: {created_lease.leaseID}")
        except (CarNotFoundException, CustomerNotFoundException) as e:
            raise e
    def return_car(self):
        print("Return Car:")
        lease_id = int(input("Enter Lease ID to return the car: "))
        try:
            returned_lease = self.car_repository.returnCar(lease_id)
            print(f"Car returned successfully. Lease ID: {returned_lease.leaseID}")
        except LeaseNotFoundException as e:
            print(f"Error: {e}")

    def find_lease_by_id(self):
        print("Finding lease by id")
        lease_id = int(input("Enter lease ID: "))
        try:

            lease = self.car_repository.findLeaseById(lease_id)
            print("Lease found:")
            print(f"Lease ID:,{lease.leaseID}, leaese-type: {lease.type}")
        except LeaseNotFoundException as e:
            print(f"Error: {e}")

    def list_active_leases(self):
        print("List Active Leases:")
        active_leases = self.car_repository.listActiveLeases()

        if active_leases:
            print("Active Leases:")
            for lease in active_leases:
                print(f"Lease ID: {lease.leaseID} - Start Date: {lease.startDate} - End Date: {lease.endDate}")
        else:
            print("No active leases.")

    def list_lease_history(self):
        print("List Lease History:")
        lease_history = self.car_repository.listLeaseHistory()

        if lease_history:
            print("Lease History:")
            for lease in lease_history:
                print(f"Lease ID: {lease.leaseID} - Start Date: {lease.startDate} - End Date: {lease.endDate}")
        else:
            print("No lease history.")

    def record_payment(self):
        print("Record Payment:")
        lease_id = int(input("Enter Lease ID for payment: "))
        amount = float(input("Enter Payment Amount: "))

        try:
            lease = self.car_repository.findLeaseById(lease_id)
            self.car_repository.recordPayment(lease, amount)
            print("Payment recorded successfully.")
        except LeaseNotFoundException as e:
            print(f"Error: {e}")

    def retrieve_payment_history(self):
        try:
            customer_id = int(input("Enter Lease ID: "))
            payment_history = self.car_repository.retrievePaymentHistory(customer_id)
            if payment_history:
                print("Payment History:")
                for payment in payment_history:
                    print(f"Payment ID: {payment.paymentID}, Amount: {payment.amount}, Date: {payment.paymentDate}")
            else:
                print("No payment history found.")
        except CustomerNotFoundException as e:
            print(f"Error: {e}")

    def calculate_total_revenue(self):
        try:
            total_revenue = self.car_repository.calculateTotalRevenue()
            print(f"Total Revenue: {total_revenue}")
        except Exception as e:
            print(f"Error: {e}")


if __name__ == "__main__":
    main_module = MainModule()
    main_module.run()
