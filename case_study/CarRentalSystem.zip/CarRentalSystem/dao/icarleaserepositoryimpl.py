import mysql.connector
from dao.icarleaserepository import ICarLeaseRepository
from entity.payment import Payment
from entity.vehicle import Vehicle
from entity.customer import Customer
from entity.lease import Lease
from exception.car_not_found_exception import CarNotFoundException
from exception.customer_not_found_exception import CustomerNotFoundException
from exception.lease_not_found_exception import LeaseNotFoundException, ActiveLeasesExistException
from typing import List
from datetime import datetime


class ICarLeaseRepositoryImpl(ICarLeaseRepository):
    def __init__(self, connection=None):
        self.connection = connection

    def addCar(self, car: Vehicle):
        cursor = self.connection.cursor()
        try:
            cursor.execute(
                "INSERT INTO vehicle (make, model, year, dailyRate, status, passengerCapacity, engineCapacity) "
                "VALUES (%s, %s, %s, %s, %s, %s, %s)",
                (car.make, car.model, car.year, car.dailyRate, car.status,
                 car.passengerCapacity, car.engineCapacity))
            self.connection.commit()
        finally:
            cursor.close()

    def removeCar(self, carID: int):
        cursor = self.connection.cursor()
        try:
            # Check if the car has active leases
            active_leases = self.listActiveLeases()
            active_leases_for_car = [lease for lease in active_leases if lease.vehicleID == carID]

            if active_leases_for_car:
                raise ActiveLeasesExistException("Cannot remove car with active leases.")

            cursor.execute("DELETE FROM vehicle WHERE vehicleID=%s", (carID,))
            if cursor.rowcount == 0:
                raise CarNotFoundException(f"Car with ID {carID} not found.")
            self.connection.commit()
        finally:
            cursor.close()

    def listAvailableCars(self) -> List[Vehicle]:
        cursor = self.connection.cursor()
        try:
            cursor.execute("SELECT * FROM vehicle WHERE status='available'")
            rows = cursor.fetchall()

            cars = []
            for row in rows:
                car = Vehicle(row[0], row[1], row[2], row[3], row[4], row[5], row[6], row[7])
                cars.append(car)

            return cars
        finally:
            cursor.close()

    def listRentedCars(self) -> List[Vehicle]:
        cursor = self.connection.cursor()
        try:
            cursor.execute("SELECT * FROM vehicle WHERE status='notAvailable'")
            rows = cursor.fetchall()

            cars = []
            for row in rows:
                car = Vehicle(row[0], row[1], row[2], row[3], row[4], row[5], row[6], row[7])
                cars.append(car)

            return cars
        finally:
            cursor.close()

    def findCarById(self, carID: int) -> Vehicle:
        cursor = self.connection.cursor()
        try:
            cursor.execute("SELECT * FROM vehicle WHERE vehicleID=%s", (carID,))
            row = cursor.fetchone()

            if row:
                return Vehicle(row[0], row[1], row[2], row[3], row[4], row[5], row[6], row[7])
            else:
                raise CarNotFoundException(f"Car with ID {carID} not found.")
        finally:
            cursor.close()

    def addCustomer(self, customer: Customer):
        cursor = self.connection.cursor()
        try:
            cursor.execute("INSERT INTO customer (firstName, lastName, email, phoneNumber) VALUES (%s, %s, %s, %s)",
                           (customer.firstName, customer.lastName, customer.email, customer.phoneNumber))
            self.connection.commit()
        finally:
            cursor.close()

    def removeCustomer(self, customerID: int):
        cursor = self.connection.cursor()
        try:
            # Check if the customer has active leases
            active_leases = self.listActiveLeases()
            active_leases_for_customer = [lease for lease in active_leases if lease.customerID == customerID]

            if active_leases_for_customer:
                raise ActiveLeasesExistException("Cannot remove customer with active leases.")

            cursor.execute("DELETE FROM customer WHERE customerID=%s", (customerID,))
            self.connection.commit()
        finally:
            cursor.close()

    def listCustomers(self) -> List[Customer]:
        cursor = self.connection.cursor()
        try:
            cursor.execute("SELECT * FROM customer")
            rows = cursor.fetchall()

            customers = []
            for row in rows:
                customer = Customer(row[0], row[1], row[2], row[3], row[4])
                customers.append(customer)

            return customers
        finally:
            cursor.close()

    def findCustomerById(self, customerID: int) -> Customer:
        cursor = self.connection.cursor()
        try:
            cursor.execute("SELECT * FROM customer WHERE customerID=%s", (customerID,))
            row = cursor.fetchone()

            if row:
                return Customer(row[0], row[1], row[2], row[3], row[4])
            else:
                raise CustomerNotFoundException(f"Customer with ID {customerID} not found.")
        finally:
            cursor.close()

    def createLease(self, customerID: int, carID: int, startDate, endDate, lease_type) -> Lease:
        cursor = self.connection.cursor()
        try:
            cursor.execute(
                "INSERT INTO lease (vehicleID, customerID, startDate, endDate, type ) VALUES (%s, %s, %s, %s, %s)",
                (carID, customerID, startDate, endDate, lease_type))
            self.connection.commit()
            cursor.execute("SELECT LAST_INSERT_ID()")
            leaseID = cursor.fetchone()[0]

            return Lease(leaseID, carID, customerID, startDate, endDate,
                         lease_type)
        finally:
            cursor.close()

    def returnCar(self, leaseID: int) -> Lease:
        cursor = self.connection.cursor()
        try:
            cursor.execute("UPDATE lease SET endDate = %s WHERE leaseID = %s",
                           (datetime.now().date(), leaseID))
            self.connection.commit()
            return self.findLeaseById(leaseID)
        finally:
            cursor.close()

    def findLeaseById(self, leaseID: int) -> Lease:
        cursor = self.connection.cursor()
        try:
            cursor.execute("SELECT * FROM lease WHERE leaseID = %s", (leaseID,))
            result = cursor.fetchone()

            if result:
                lease_id, car_id, customer_id, start_date, end_date, type = result
                return Lease(lease_id, car_id, customer_id, start_date, end_date, type)
            else:
                raise LeaseNotFoundException(f"Lease with ID {leaseID} not found.")
        finally:
            cursor.close()

    def listActiveLeases(self) -> List[Lease]:
        cursor = self.connection.cursor()
        try:
            cursor.execute("SELECT * FROM lease WHERE startDate <= CURDATE() AND endDate >= CURDATE()")
            rows = cursor.fetchall()
            leases = []
            for row in rows:
                lease = Lease(row[0], row[1], row[2], row[3], row[4], row[5])
                leases.append(lease)

            return leases
        finally:
            cursor.close()

    def listLeaseHistory(self) -> List[Lease]:
        if not self.connection:
            raise ValueError("Connection is not provided.")
        cursor = self.connection.cursor()
        try:
            cursor.execute("SELECT * FROM lease")
            rows = cursor.fetchall()

            leases = []
            for row in rows:
                lease = Lease(row[0], row[1], row[2], row[3], row[4], row[5])
                leases.append(lease)
            return leases
        finally:
            cursor.close()

    def recordPayment(self, lease: Lease, amount: float):
        cursor = self.connection.cursor()
        try:
            print("Lease id", lease.leaseID)
            cursor.execute("INSERT INTO payment (leaseID, paymentDate, amount) VALUES (%s, %s, %s)",
                           (lease.leaseID, datetime.now().strftime("%Y-%m-%d"), amount))
            self.connection.commit()
        finally:
            cursor.close()

    def retrievePaymentHistory(self, leaseID: int) -> List[Payment]:
        cursor = self.connection.cursor()
        try:
            cursor.execute("SELECT * FROM Payment WHERE leaseID = %s", (leaseID,))
            rows = cursor.fetchall()
            payment_history = []
            for row in rows:
                payment = Payment(row[0], row[1], row[2], row[3])
                payment_history.append(payment)
            self.connection.commit()
            return payment_history
        except Exception as e:
            raise LeaseNotFoundException(f"Lease with ID {leaseID} not found.") from e
        finally:
            cursor.close()

    def calculateTotalRevenue(self) -> float:
        cursor = self.connection.cursor()
        try:
            cursor.execute("SELECT SUM(amount) FROM Payment")
            total_revenue = cursor.fetchone()[0]
            return total_revenue
        finally:
            cursor.close()

    def update_customer_info(self, customer_id, email=None, phoneNumber=None):
        try:
            cursor = self.connection.cursor()
            sql = "UPDATE Customer SET"
            val = []

            if email is not None:
                sql += " Email=%s,"
                val.append(email)

            if phoneNumber is not None:
                sql += " phoneNumber=%s,"
                val.append(phoneNumber)

            # Remove the trailing comma from the SQL query
            if len(val) > 0:
                sql = sql.rstrip(',')
                sql += " WHERE CustomerID=%s"
                val.append(customer_id)

                cursor.execute(sql, val)
                self.connection.commit()
                cursor.close()
                return True
            else:
                print("No parameters provided for update")
                return False
        except mysql.connector.Error as e:
            print(f"Error updating customer: {e}")
            raise Exception("Error updating customer")


