import mysql.connector
from dao.icarleaserepository import ICarLeaseRepository
from entity.vehicle import Vehicle
from entity.customer import Customer
from entity.lease import Lease
from exception.car_not_found_exception import CarNotFoundException
from exception.customer_not_found_exception import CustomerNotFoundException
from exception.lease_not_found_exception import LeaseNotFoundException
from typing import List
from datetime import datetime


class ICarLeaseRepositoryImpl(ICarLeaseRepository):
    def __init__(self, connection=None):
        self.connection = connection

    def addCar(self, car: Vehicle):
        cursor = self.connection.cursor()
        try:
            cursor.execute(
                "INSERT INTO vehicle (make, model, year, dailyRate, status, passengerCapacity, engineCapacity) "
                "VALUES (%s, %s, %s, %s, %s, %s, %s)",
                (car.make, car.model, car.year, car.dailyRate, car.status,
                 car.passengerCapacity, car.engineCapacity))
            self.connection.commit()
        finally:
            cursor.close()

    def removeCar(self, carID: int):
        cursor = self.connection.cursor()

        try:
            cursor.execute("DELETE FROM vehicle WHERE vehicleID=%s", (carID,))
            if cursor.rowcount == 0:
                raise CarNotFoundException(f"Car with ID {carID} not found.")
            self.connection.commit()
        finally:
            cursor.close()

    def listAvailableCars(self) -> List[Vehicle]:
        cursor = self.connection.cursor()
        try:
            cursor.execute("SELECT * FROM vehicle WHERE status='available'")
            rows = cursor.fetchall()

            cars = []
            for row in rows:
                car = Vehicle(row[0], row[1], row[2], row[3], row[4], row[5], row[6], row[7])
                cars.append(car)

            return cars
        finally:
            cursor.close()

    def listRentedCars(self) -> List[Vehicle]:
        cursor = self.connection.cursor()
        try:
            cursor.execute("SELECT * FROM vehicle WHERE status='notAvailable'")
            rows = cursor.fetchall()

            cars = []
            for row in rows:
                car = Vehicle(row[0], row[1], row[2], row[3], row[4], row[5], row[6], row[7])
                cars.append(car)

            return cars
        finally:
            cursor.close()

    def findCarById(self, carID: int) -> Vehicle:
        cursor = self.connection.cursor()
        try:
            cursor.execute("SELECT * FROM vehicle WHERE vehicleID=%s", (carID,))
            row = cursor.fetchone()

            if row:
                return Vehicle(row[0], row[1], row[2], row[3], row[4], row[5], row[6], row[7])
            else:
                raise CarNotFoundException(f"Car with ID {carID} not found.")
        finally:
            cursor.close()

    def addCustomer(self, customer: Customer):
        cursor = self.connection.cursor()
        try:
            cursor.execute("INSERT INTO customer (firstName, lastName, email, phoneNumber) VALUES (%s, %s, %s, %s)",
                           (customer.firstName, customer.lastName, customer.email, customer.phoneNumber))
            self.connection.commit()
        finally:
            cursor.close()

    def removeCustomer(self, customerID: int):
        if not self.connection:
            raise ValueError("Connection is not provided.")

        cursor = self.connection.cursor()
        try:
            cursor.execute("DELETE FROM customer WHERE customerID=%s", (customerID,))
            self.connection.commit()
        finally:
            cursor.close()

    def listCustomers(self) -> List[Customer]:
        cursor = self.connection.cursor()
        try:
            cursor.execute("SELECT * FROM customer")
            rows = cursor.fetchall()

            customers = []
            for row in rows:
                customer = Customer(row[0], row[1], row[2], row[3], row[4])
                customers.append(customer)

            return customers
        finally:
            cursor.close()

    def findCustomerById(self, customerID: int) -> Customer:
        cursor = self.connection.cursor()
        try:
            cursor.execute("SELECT * FROM customer WHERE customerID=%s", (customerID,))
            row = cursor.fetchone()

            if row:
                return Customer(row[0], row[1], row[2], row[3], row[4])
            else:
                raise CustomerNotFoundException(f"Customer with ID {customerID} not found.")
        finally:
            cursor.close()

    def createLease(self, customerID: int, carID: int, startDate, endDate, lease_type) -> Lease:
        cursor = self.connection.cursor()
        try:
            cursor.execute(
                "INSERT INTO lease (vehicleID, customerID, startDate, endDate, type ) VALUES (%s, %s, %s, %s, %s)",
                (carID, customerID, startDate, endDate, lease_type))
            self.connection.commit()
            cursor.execute("SELECT LAST_INSERT_ID()")
            leaseID = cursor.fetchone()[0]

            return Lease(leaseID, carID, customerID, startDate, endDate,
                         lease_type)
        finally:
            cursor.close()

    def returnCar(self, leaseID: int) -> Lease:
        cursor = self.connection.cursor()
        try:
            cursor.execute("UPDATE lease SET endDate = %s WHERE leaseID = %s",
                           (datetime.now().date(), leaseID))
            self.connection.commit()
            return self.findLeaseById(leaseID)
        finally:
            cursor.close()

    def findLeaseById(self, leaseID: int) -> Lease:
        cursor = self.connection.cursor()
        try:
            cursor.execute("SELECT * FROM lease WHERE leaseID = %s", (leaseID,))
            result = cursor.fetchone()

            if result:
                lease_id, car_id, customer_id, start_date, end_date, type = result
                return Lease(lease_id, car_id, customer_id, start_date, end_date, type)
            else:
                raise LeaseNotFoundException(f"Lease with ID {leaseID} not found.")
        finally:
            cursor.close()

    def listActiveLeases(self) -> List[Lease]:
        cursor = self.connection.cursor()
        try:
            cursor.execute("SELECT * FROM lease WHERE startDate <= CURDATE() AND endDate >= CURDATE()")
            rows = cursor.fetchall()
            leases = []
            for row in rows:
                lease = Lease(row[0], row[1], row[2], row[3], row[4], row[5])
                leases.append(lease)

            return leases
        finally:
            cursor.close()

    def listLeaseHistory(self) -> List[Lease]:
        if not self.connection:
            raise ValueError("Connection is not provided.")
        cursor = self.connection.cursor()
        try:
            cursor.execute("SELECT * FROM lease")
            rows = cursor.fetchall()

            leases = []
            for row in rows:
                lease = Lease(row[0], row[1], row[2], row[3], row[4], row[5])
                leases.append(lease)
            return leases
        finally:
            cursor.close()

    def recordPayment(self, lease: Lease, amount: float):
        cursor = self.connection.cursor()
        try:
            print("Lease id", lease.leaseID)
            cursor.execute("INSERT INTO payment (leaseID, paymentDate, amount) VALUES (%s, %s, %s)",
                           (lease.leaseID, datetime.now().strftime("%Y-%m-%d"), amount))
            self.connection.commit()
        finally:
            cursor.close()
