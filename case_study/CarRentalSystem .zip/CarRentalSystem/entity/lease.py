class Lease:
    def __init__(self, leaseID, vehicleID, customerID, startDate, endDate, type):
        self._leaseID = leaseID
        self._vehicleID = vehicleID
        self._customerID = customerID
        self._startDate = startDate
        self._endDate = endDate
        self._type = type


    @property
    def leaseID(self):
        return self._leaseID

    @property
    def vehicleID(self):
        return self._vehicleID

    @property
    def customerID(self):
        return self._customerID

    @property
    def startDate(self):
        return self._startDate

    @property
    def endDate(self):
        return self._endDate

    @property
    def type(self):
        return self._type

