class Customer:
    def __init__(self, customerID, firstName, lastName, email, phoneNumber):
        self._customerID = customerID
        self._firstName = firstName
        self._lastName = lastName
        self._email = email
        self._phoneNumber = phoneNumber

    @property
    def customerID(self):
        return self._customerID

    @property
    def firstName(self):
        return self._firstName

    @property
    def lastName(self):
        return self._lastName

    @property
    def email(self):
        return self._email

    @property
    def phoneNumber(self):
        return self._phoneNumber
