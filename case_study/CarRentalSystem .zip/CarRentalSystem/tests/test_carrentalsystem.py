import pytest
from main.mainmodule import MainModule
from dao.icarleaserepositoryimpl import ICarLeaseRepositoryImpl
from entity.vehicle import Vehicle
from exception.car_not_found_exception import CarNotFoundException
from exception.customer_not_found_exception import CustomerNotFoundException
from exception.lease_not_found_exception import LeaseNotFoundException
import datetime
from util.dbconnection import DBConnection


@pytest.fixture
def car_repository():
    connection = DBConnection.getConnection()
    return ICarLeaseRepositoryImpl(connection)


@pytest.fixture
def main_module(car_repository):
    return MainModule()


def test_add_car(main_module, car_repository):
    car_id = 1
    make = "Toyota"
    model = "Camry"
    year = 2022
    daily_rate = 50
    status = "available"
    passenger_capacity = 4
    engine_capacity = 1450

    new_car = Vehicle(car_id, make, model, year, daily_rate, status, passenger_capacity, engine_capacity)
    car_repository.addCar(new_car)

    assert car_repository.findCarById(new_car.vehicleID)



def test_create_lease(main_module, car_repository):
    customer_id = 1
    car_id = 1
    start_date = datetime.datetime.now().strftime("%Y-%m-%d")
    end_date = "2024-02-09"
    lease_type = "Monthly"

    created_lease = car_repository.createLease(customer_id, car_id, start_date, end_date, lease_type)

    assert car_repository.findLeaseById(created_lease.leaseID)



def test_retrieve_lease(main_module, car_repository):
    lease_id = 1
    retrieved_lease = car_repository.findLeaseById(lease_id)
    assert retrieved_lease is not None


def test_exception_for_customer_not_found(main_module, car_repository):
    with pytest.raises(CustomerNotFoundException):
        car_repository.findCustomerById(9855)


def test_exception_for_car_not_found(main_module, car_repository):
    with pytest.raises(CarNotFoundException):
        car_repository.findCarById(9999)


def test_exception_for_lease_not_found(main_module, car_repository):
    with pytest.raises(LeaseNotFoundException):
        car_repository.findLeaseById(9999)
